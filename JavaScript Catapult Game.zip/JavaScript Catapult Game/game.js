import { drawCatapult } from './catapult.js';
import { drawTargets } from './Targets.js';


const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

const cans = Array.from({ length: 10 }, randomThing);
let p, play = false;

let dragging = false;
let controlPoint = { x: 300, y: 450 };
let velocity = { x: 0, y: 0 };
let lastMousePos = { x: 300, y: 300 };
let isMoving = false;

// Stopwatch variables
let startTime = null; // To store the start time
let elapsedTime = 0; // To store elapsed time
let gameFinished = false; // To check if the game is finished

// Get proper mouse coordinates relative to the canvas
function getMousePos(canvas, event) {
    const rect = canvas.getBoundingClientRect();
    return {
        x: (event.clientX - rect.left) * (canvas.width / rect.width),
        y: (event.clientY - rect.top) * (canvas.height / rect.height)
    };
}

function frame(ts) {
    const elapsed = (ts - p) || 0;
    update(elapsed / 1000);
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawTargets(ctx, cans);
    drawCatapult(ctx, controlPoint.x, controlPoint.y, isMoving);
    drawStopwatch(); // Draw the stopwatch on the canvas
    p = ts;
    if (play && cans.length > 0 && !gameFinished) requestAnimationFrame(frame); // Only continue animation if cans are still there
}

function update(elapsed) {
    // Determine if the control point is moving
    if (Math.abs(velocity.x) > 0 || Math.abs(velocity.y) > 0) 
    {
        isMoving = true;
    }
    else
    {
        isMoving = false;
    }

    // Update control point position
    controlPoint.x += velocity.x * elapsed;
    controlPoint.y += velocity.y * elapsed;

    const slowdownFactor = 0.8;

    // If the control point hits the edge of the canvas, reset its position to (300, 300)
    if (controlPoint.x <= 0 || controlPoint.x >= canvas.width || controlPoint.y <= 0 || controlPoint.y >= canvas.height) {
        controlPoint.x = 300;  // Reset to center x position
        controlPoint.y = 450;  // Reset to center y position
        velocity.x = 0;  // Stop movement
        velocity.y = 0;
    }

    // Gradual stop condition
    if (Math.abs(velocity.x) < 0.1) velocity.x = 0;
    if (Math.abs(velocity.y) < 0.1) velocity.y = 0;

    // Check for collision with cans, but only if the ball is not being dragged
    if (!dragging) {
        for (let i = cans.length - 1; i >= 0; i--) {
            const can = cans[i];
            const dx = controlPoint.x - can.x;
            const dy = controlPoint.y - can.y;
            const distance = Math.sqrt(dx * dx + dy * dy);

            // Check if the ball is within the hitbox (larger radius)
            const canHitboxRadius = 30; // Bigger hitbox radius
            if (distance <= canHitboxRadius) {
                cans.splice(i, 1); // Remove the can from the array
                velocity.x *= 0.9; // Reduce velocity slightly after hitting a can
                velocity.y *= 0.9;
            }
        }
    }

    // Check if all cans are destroyed
    if (cans.length === 0 && !gameFinished) {
        gameFinished = true; // Set gameFinished to true once cans are all destroyed
        elapsedTime = (performance.now() - startTime) / 1000; // Calculate elapsed time
    }

    // Update cans' movement
    cans.forEach(can => {
        can.x += can.xSpeed * elapsed;
        can.y += can.ySpeed * elapsed;
        if (can.x < 0) can.x = canvas.width;
        if (can.y < 0) can.y = canvas.height;
        if (can.x > canvas.width) can.x = 0;
        if (can.y > canvas.height) can.y = 0;
    });
}

function randomThing() {
    return {
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        xSpeed: (Math.random() - 0.5) * 200,
        ySpeed: (Math.random() - 0.5) * 200,
    };
}

function drawStopwatch() {
    ctx.font = "30px Arial";
    ctx.fillStyle = "black";

    let timeDisplay;
    if (gameFinished) {
        timeDisplay = `Time: ${elapsedTime.toFixed(2)}s (All Cans Destroyed)`;
    } else {
        timeDisplay = `Time: ${(elapsedTime + (performance.now() - startTime) / 1000).toFixed(2)}s`;
    }

    ctx.fillText(timeDisplay, 10, 30);
}

// Initial drawing
drawCatapult(ctx, controlPoint.x, controlPoint.y, isMoving);



// Play button
const btn = document.getElementById("btn");
btn.addEventListener('click', () => {
    play = !play;
    btn.textContent = play ? "Pause" : "Play";
    if (play) {
        if (cans.length === 10) { // If it's a new game
            startTime = performance.now(); // Record start time
            elapsedTime = 0; // Reset elapsed time
            gameFinished = false; // Reset the gameFinished flag
        }
        p = undefined;
        requestAnimationFrame(frame);
    }
});

// Click and drag
canvas.addEventListener('mousedown', ev => {
    const mousePos = getMousePos(canvas, ev);
    const distance = Math.sqrt((mousePos.x - controlPoint.x) ** 2 + (mousePos.y - controlPoint.y) ** 2);
    if (distance <= 20) {
        dragging = true;
        lastMousePos = { ...mousePos };
    }
});

canvas.addEventListener('mousemove', ev => {
    if (dragging) {
        const mousePos = getMousePos(canvas, ev);
        controlPoint.x = mousePos.x;
        controlPoint.y = mousePos.y;
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        drawTargets(ctx, cans);
        drawCatapult(ctx, controlPoint.x, controlPoint.y, isMoving);
    }
});

canvas.addEventListener('mouseup', ev => {
    if (dragging) {
        dragging = false;
        const mousePos = getMousePos(canvas, ev);
        const dx = lastMousePos.x - mousePos.x;
        const dy = lastMousePos.y - mousePos.y;
        const magnitude = Math.sqrt(dx ** 2 + dy ** 2) || 1;
        const speedMultiplier = 500;
        velocity.x = (dx / magnitude) * speedMultiplier;
        velocity.y = (dy / magnitude) * speedMultiplier;
    }
});
