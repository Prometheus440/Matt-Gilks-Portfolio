export function drawTargets(ctx, target) {
    target.forEach(target => {
        ctx.save();
        ctx.fillStyle = "#9e0303";
        ctx.lineWidth = 9;
        ctx.beginPath();
        ctx.arc(target.x, target.y, 50, 0, 2 * Math.PI);
        ctx.fill();
        
        ctx.beginPath();
        ctx.fillStyle = "white";
        ctx.arc(target.x, target.y, 40, 0, 2 * Math.PI);
        ctx.fill();
        
        ctx.fillStyle = "#9e0303";
        ctx.beginPath();
        ctx.arc(target.x, target.y, 30, 0, 2 * Math.PI);
        ctx.fill();
        
        ctx.beginPath();
        ctx.fillStyle = "white";
        ctx.arc(target.x, target.y, 20, 0, 2 * Math.PI);
        ctx.fill();
        
        ctx.fillStyle = "#9e0303";
        ctx.beginPath();
        ctx.arc(target.x, target.y, 10, 0, 2 * Math.PI);
        ctx.fill();
        ctx.restore();
    });
}
