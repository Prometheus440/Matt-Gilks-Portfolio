export function drawCatapult(ctx, ctlX, ctlY, isMoving) {
    // Catapult base
    ctx.save();
    ctx.beginPath();
    ctx.lineWidth = 40;
    ctx.moveTo(300, 450);
    ctx.lineTo(200, 400);
    ctx.strokeStyle = "#774300";
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(300, 450);
    ctx.lineTo(400, 400);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(300, 450);
    ctx.lineTo(300, 575);
    ctx.stroke();
    ctx.restore();

    // Connectors
    ctx.save();
    ctx.beginPath();
    ctx.fillStyle = "grey";
    ctx.arc(200, 400, 8, 0, 2 * Math.PI);
    ctx.fill();

    ctx.beginPath();
    ctx.fillStyle = "grey";
    ctx.arc(400, 400, 8, 0, 2 * Math.PI);
    ctx.fill();    
    ctx.restore();

    // Control point string
    ctx.save();
    ctx.fillStyle = "yellow";
    ctx.beginPath();
    ctx.arc(ctlX, ctlY, 20, 0, 2 * Math.PI);
    ctx.fill();
    ctx.restore();

    if (!isMoving)
    {
        ctx.save();
        ctx.strokeStyle = "white";
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(200, 400);
        ctx.lineTo(ctlX, ctlY);
        ctx.lineTo(400, 400);
        ctx.stroke();
        ctx.restore();
    }
}